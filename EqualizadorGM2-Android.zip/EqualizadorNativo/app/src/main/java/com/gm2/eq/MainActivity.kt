package com.gm2.eq

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*

class MainActivity : Activity() {
    private val BG = Color.parseColor("#14181D")
    private val TX = Color.parseColor("#E8EDF2")
    private val MU = Color.parseColor("#8B98A6")
    private val AC = Color.parseColor("#3DDCC4")
    private val bars = ArrayList<SeekBar>()
    private val vals = ArrayList<TextView>()
    private var minLv = -1500
    private lateinit var status: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(t: String, size: Float = 15f, c: Int = TX) =
        TextView(this).apply { text = t; textSize = size; setTextColor(c) }
    private fun tint(s: SeekBar) {
        s.progressTintList = ColorStateList.valueOf(AC); s.thumbTintList = ColorStateList.valueOf(AC)
    }
    private fun fmtDb(mb: Int) = String.format("%+.1f dB", mb / 100f)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val p = EffectManager.prefs(this)
        EffectManager.open(applicationContext, 0)
        val si = Intent(this, EqService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(si) else startService(si)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); fitsSystemWindows = true; addView(root) })

        root.addView(label("Equalizador GM2", 24f))
        status = label("", 13f, MU); root.addView(status)

        val sw = Switch(this).apply {
            text = "Ligado"; setTextColor(TX); isChecked = p.getBoolean("on", true)
            setOnCheckedChangeListener { _, on ->
                p.edit().putBoolean("on", on).apply(); EffectManager.applyAll(this@MainActivity)
            }
        }
        root.addView(sw)

        val pr = EffectManager.eq(0)
        if (pr == null) {
            root.addView(label("Este aparelho não liberou o equalizador global. O app ainda atua nos players que enviam a sessão de áudio, mas as bandas não aparecem aqui.", 14f, MU))
        } else {
            minLv = pr.bandLevelRange[0].toInt()
            val maxLv = pr.bandLevelRange[1].toInt()

            val hs = HorizontalScrollView(this); val row = LinearLayout(this); hs.addView(row)
            for (k in 0 until pr.numberOfPresets) {
                row.addView(Button(this).apply {
                    text = pr.getPresetName(k.toShort())
                    setOnClickListener {
                        pr.usePreset(k.toShort())
                        val e = p.edit()
                        for (i in 0 until pr.numberOfBands) {
                            val lv = pr.getBandLevel(i.toShort()).toInt()
                            e.putInt("band$i", lv); bars[i].progress = lv - minLv; vals[i].text = fmtDb(lv)
                        }
                        e.apply(); EffectManager.applyAll(this@MainActivity)
                    }
                })
            }
            root.addView(hs)

            for (i in 0 until pr.numberOfBands) {
                val hz = pr.getCenterFreq(i.toShort()) / 1000
                val name = if (hz >= 1000) String.format("%.1f kHz", hz / 1000f) else "$hz Hz"
                val lv = p.getInt("band$i", 0).coerceIn(minLv, maxLv)
                val v = label(fmtDb(lv), 13f, AC); vals.add(v)
                val s = SeekBar(this).apply {
                    max = maxLv - minLv; progress = lv - minLv; tint(this)
                    setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(sb: SeekBar, pg: Int, user: Boolean) {
                            if (!user) return
                            val l = pg + minLv; v.text = fmtDb(l)
                            p.edit().putInt("band$i", l).apply(); EffectManager.applyAll(this@MainActivity)
                        }
                        override fun onStartTrackingTouch(sb: SeekBar) {}
                        override fun onStopTrackingTouch(sb: SeekBar) {}
                    })
                }
                bars.add(s)
                val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                r.addView(label(name, 13f, MU), LinearLayout.LayoutParams(dp(70), WRAP_CONTENT))
                r.addView(s, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
                r.addView(v, LinearLayout.LayoutParams(dp(72), WRAP_CONTENT))
                root.addView(r)
            }
        }

        extra(root, "Graves", "bass", 1000) { "${it / 10}%" }
        extra(root, "Volume extra", "loud", 1500) { "+${it / 100f} dB" }

        root.addView(Button(this).apply {
            text = "Zerar tudo"
            setOnClickListener {
                val on = p.getBoolean("on", true)
                p.edit().clear().putBoolean("on", on).apply()
                EffectManager.applyAll(this@MainActivity); recreate()
            }
        })
        root.addView(label("Funciona com players que enviam a sessão de áudio (Spotify, YouTube Music, Poweramp, VLC…) e, em muitos aparelhos, com o som geral. O ajuste vale para qualquer saída, inclusive o fone Bluetooth.", 12f, MU))
    }

    private fun extra(root: LinearLayout, name: String, key: String, max: Int, fmt: (Int) -> String) {
        val p = EffectManager.prefs(this)
        val v = label(fmt(p.getInt(key, 0)), 13f, AC)
        val s = SeekBar(this).apply {
            this.max = max; progress = p.getInt(key, 0); tint(this)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, pg: Int, user: Boolean) {
                    if (!user) return
                    v.text = fmt(pg); p.edit().putInt(key, pg).apply(); EffectManager.applyAll(this@MainActivity)
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
        r.addView(label(name, 13f, MU), LinearLayout.LayoutParams(dp(70), WRAP_CONTENT))
        r.addView(s, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        r.addView(v, LinearLayout.LayoutParams(dp(72), WRAP_CONTENT))
        root.addView(r)
    }

    override fun onResume() {
        super.onResume()
        status.text = "Sessões de áudio ativas: ${EffectManager.sessionCount()}"
    }
}
