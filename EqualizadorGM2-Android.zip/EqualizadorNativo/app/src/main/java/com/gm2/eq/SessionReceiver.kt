package com.gm2.eq

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect

/** Players como Spotify e YouTube Music avisam aqui quando abrem/fecham a sessão de áudio. */
class SessionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = i.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
        if (s < 0) return
        when (i.action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> EffectManager.open(c.applicationContext, s)
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> EffectManager.close(s)
        }
    }
}
