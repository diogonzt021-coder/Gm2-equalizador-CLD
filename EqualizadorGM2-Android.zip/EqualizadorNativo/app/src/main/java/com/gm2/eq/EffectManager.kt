package com.gm2.eq

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer

/** Guarda os efeitos de áudio de cada sessão (0 = global) e aplica os ajustes salvos. */
object EffectManager {
    private class Fx(val eq: Equalizer, val bass: BassBoost?, val loud: LoudnessEnhancer?) {
        fun release() {
            runCatching { eq.release() }
            runCatching { bass?.release() }
            runCatching { loud?.release() }
        }
    }

    private val fx = HashMap<Int, Fx>()

    fun prefs(c: Context) = c.getSharedPreferences("eq", Context.MODE_PRIVATE)

    @Synchronized fun open(c: Context, session: Int) {
        if (fx.containsKey(session)) return
        try {
            val f = Fx(
                Equalizer(0, session),
                runCatching { BassBoost(0, session) }.getOrNull(),
                runCatching { LoudnessEnhancer(session) }.getOrNull()
            )
            fx[session] = f
            apply(c, f)
        } catch (_: Throwable) { /* aparelho não permite esta sessão */ }
    }

    @Synchronized fun close(session: Int) { if (session != 0) fx.remove(session)?.release() }
    @Synchronized fun applyAll(c: Context) { fx.values.forEach { apply(c, it) } }
    @Synchronized fun eq(session: Int): Equalizer? = fx[session]?.eq
    @Synchronized fun sessionCount() = fx.size

    private fun apply(c: Context, f: Fx) {
        val p = prefs(c)
        val on = p.getBoolean("on", true)
        runCatching {
            val min = f.eq.bandLevelRange[0].toInt()
            val max = f.eq.bandLevelRange[1].toInt()
            for (i in 0 until f.eq.numberOfBands) {
                val lv = p.getInt("band$i", 0).coerceIn(min, max)
                f.eq.setBandLevel(i.toShort(), lv.toShort())
            }
            f.eq.enabled = on
        }
        runCatching {
            f.bass?.let { val s = p.getInt("bass", 0); it.setStrength(s.toShort()); it.enabled = on && s > 0 }
        }
        runCatching {
            f.loud?.let { val g = p.getInt("loud", 0); it.setTargetGain(g); it.enabled = on && g > 0 }
        }
    }
}
